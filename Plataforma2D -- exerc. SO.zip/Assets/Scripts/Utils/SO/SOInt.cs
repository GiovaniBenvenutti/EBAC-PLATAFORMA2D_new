using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "SOInt", menuName = "ScriptableObjects/SOInt", order = 1)]
public class SOInt : ScriptableObject
{
    public int value;
}
