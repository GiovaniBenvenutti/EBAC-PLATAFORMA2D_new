using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "SOFloat", menuName = "ScriptableObjects/SOFloat", order = 1)]
public class SOFloat : ScriptableObject
{
    public float value;
    
}
